<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>index</title>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>
</head>
<body>
	<header>
		<h1 class="judul">Raidzna</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua.</p>
	</header>

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="biodata.php">Biodata</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Lainnya</a>
    <div class="dropdown-content">
      <a href="visi_misi.php">Visi Misi</a>
      <a href="galeri.php">Galeri</a>
      <a href="diari.php">Diari</a>
      <a href="denah.php">Denah</a>
      <a href="login.php">Login</a>
      <a href="file_upload.php">File Upload</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul>
<br>
<img src="images/apply2.jpg" align="right" width="40%">
<h3 align="left">Lilitan Jarak</h3>
<p align="left">Entah hal nya sebuah kebetulan kau...</p>
<p align="left">melewati jalur di hatiku setiap hari</p>
<p align="left">Di balik semua itu hanyalah...</p>
<p align="left">Tersisa hati yang kosong</p>
<p align="left">Layaknya ombaok kau...</p>
<p align="left">Menerjang diriku lebih cepat</p>
<p align="left">Tapi kau tak prnah menyadari itu</p><br>
<p align="left">Keberadaan mu telah menguji ku</p>
<p align="left">Pertemuan macam apa ini kita...</p>
<p align="left">Merasa sendiri mskipun kita bersama</p>
<p align="left">Perjalanan ini terasa indah...</p>
<p align="left">Dari tujuan itu sendiri</p><br>
<p align="left">Jangan hentikan diri mu dengarlah<p>
<p align="left">Apa yang dikatakan hati mu...</p>
<p align="left">Karena kamu bisa...</p>
<p align="left">Di definisikan dengan 1 kata saja</p>

<br>
<br>
<br>
<footer>                               
        <p align="center">Copyright &copy; 2019 | Raidzna</p>
</footer>

</body>
</html>
