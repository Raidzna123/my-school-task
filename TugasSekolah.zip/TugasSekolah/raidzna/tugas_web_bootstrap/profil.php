<!DOCTYPE html>
<html>
<head>
	<title>rizky fauzy</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" href="js/jquery.js"></script>
	<script type="text/javascript" href="js/bootstrap.js"></script>
</head>
<body>
  <style>
  body {

  background-image: url(foto/bb.jpeg);
  background-size: cover;

}

.dd {
  position: relative;
  display: inline-block;
}

.dd-btn {

padding: 10px;
text-align: center;
background: #000000;
border:none;
width: 100px;
color: #f8f9f9;

}

.dd-content {
  position: absolute;
  width: 100%;
  box-shadow: 0 18px 36px rgba(0,0,0,0.30), 0 14px 11px rgba(0,0,0,0.22);
  opacity: 0;
  transition: opacity 1s;

}

.dd:hover > .dd-content {
  opacity: 1;

}

.dd-content > a {
  display: block;
  padding: 15px;
  text-decoration: none;
  color: black;
}
</style>

   <nav class="navbar navbar-success bg-success">
         <div class="container">
            <a class="navbar-brand" herf="#">
            <img src="foto/tew.png" width="250" height="75" class="d-inline-block align-top" alt="">
            </a><p align="cenetr" style="color:white; text-align: center;">SMK Bakti Nusantara 666 <br>
            Jl.Percobaan No.65,Cileunyi Kulon,Cileunyi,Bandung,Jawa Barat 40622</p> <p></p><p></p>
         </div>
   </nav>



<div class="list group" align="right" style="float: right;">
	<div class="container" align="right">
      <div class="dd">
    <button class="dd-btn">button</button>
    <div class="dd-content">
      <a href="index.html">home</a>
       <a href="galeri.html">galery</a>
        <a href="profil.html">profil</a>
      </div>
    </div>

      	</ul>
      		</div>
      			</div>


      		<div>
      		<div class="jumbotron">
      		<div class="container"><br><br>
            <h2 align="center"><b>VISI</h2>
            <li>MENJADI LEMBAGA PENDIDIKAN DAN PELATIHAN YANG BERMUTU DAN BERWAWASAN INTERNASIONAL DENGAN LULUSAN YANG MANTAP DALAM IMTAQ, UNGGUL DALAM IPTEK, BERPRESTASI SERTA SIAP BERSAING DALAM MENGHADAPI TANTANGAN GLOBAL</li>
            <h2 align="center"><b>MISI</h2>
            <li>MENGHASILKAN TAMATAN YANG MEMILIKI KETAQWAAN YANG TINGGI KEPADA TUHAN YANG MAHA ESA DAN MEMILIKI KESADARAN YANG TINGGI TERHADAP KEHARMONISAN LINGKUNGANNYA</li>
            <li>MENGHASILKAN TAMATAN YANG MEMILIKI KOMPETENSI TINGGI, MAMPU BERSAING DI PASAR TENAGA KERJA NASIONAL DAN INTERNASIONAL</li>
            <li>MENGHASILKAN TAMATAN YANG MAMPU MEMENUHI TUNTUTAN ILMU PENGETAHUAN DAN TEKNOLOGI SEBAGAI BEKAL UNTUK MENGEMBANGKAN DIRINYA</li>
            <li>MENYELENGGARAKAN PENDIDIKAN DAN PELATIHAN DIBIDANG TEKNOLOGI BAGI MASYARAKAT</li>
            <div class="message-box">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
      		<p>Di SMK Bakti Nusantara 666 memiliki 4 jurusan yaitu:</p>
            <li>Rekayasa Perangkat Lunak</li>
            <li>Desain Komunikasi Visual</li>
            <li>Animasi</li>
            <li>Akutansi</li>
      		<br>
            <br>
            <br>
            <br>

  <footer>

    <div id="header" style="border: 3px solid #dedede">
    <footer style="background: lightgreen;height: 200px; padding: 15px"><p align="center">

      <div class="container">
        <div class="row">
          <div class="col-xl-4 col--md-4">
            <div class="single-address text-center">
              <div class="address-icon">
              </div>
              <h3>lokasi kami</h3>
              <p>Jl.Percobaan No.65,Cileunyi Kulon,Cileunyi,Bandung,Jawa Barat 40622<br></p>
                </div>
              </div>
               <div class="col-xl-4 col--md-4">
            <div class="single-address text-center">
              <div class="address-icon">
              </div>
              <h3>Masuk sekolah-Pulang Sekolah</h3>
              <p>(07.00-16.00)<br>
                    Senin-Sabtu
                </div>
              </div>
               <div class="col-xl-4 col--md-4">
            <div class="single-address text-center">
              <div class="address-icon">
              </div>
              <h3>Kirim Pesan Di</h3>
              <p>rizkyfauzy801@gmail.com<br>
                    (022)70721934</p>
                </div>
              </div>

</footer>
<h5><p align="center">Copyright 2019</p></h5>
<h5><p align="center">rizkyfauzy801@gmail.com</p></h5>
<h5><p align="center">contac person:081312473572</p></h5>    



</body>
   </html>